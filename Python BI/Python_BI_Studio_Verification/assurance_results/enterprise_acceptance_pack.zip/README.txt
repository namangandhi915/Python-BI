Contains automated and pending/manual acceptance evidence only; no raw source transactions.

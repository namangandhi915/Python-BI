Offline preflight only. Public deployment is BLOCKED pending user isolation, authentication and durable storage. No source records or credentials included.

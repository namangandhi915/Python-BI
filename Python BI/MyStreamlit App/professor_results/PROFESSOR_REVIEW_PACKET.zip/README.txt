Private local academic review packet. No raw transactions included.
The professor must independently assess the final application.
